﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using iTextSharp;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.draw;

Document doc = new Document(PageSize.A4);
doc.SetMargins(40, 40, 40, 80);
doc.AddCreationDate();

string caminho = @"C:\Users\lucas.silva\Desktop\Wallpapers + ficha.pdf";

PdfWriter writer = PdfWriter.GetInstance(doc, new
    FileStream(caminho, FileMode.Create));

doc.Open();
string dados="";
Paragraph paragrafo = new Paragraph(dados,
    new Font(Font.NORMAL, 14));
paragrafo.Alignment = Element.ALIGN_JUSTIFIED;

Console.WriteLine("Digite o seu nome: ");
string nomeJogador = Console.ReadLine();
paragrafo.Add("Nome do Jogador: " + nomeJogador);
paragrafo.Add("\n");
Console.WriteLine("Digite o nome do seu personagem: ");
string nomePersonagem = Console.ReadLine();
paragrafo.Add("Nome do Personagem: " + nomePersonagem);
paragrafo.Add("\n");
Console.WriteLine("Digite a sua classe: ");
string classe = Console.ReadLine();
paragrafo.Add("Classe: " + classe);
doc.Add(paragrafo);

    doc.Close();